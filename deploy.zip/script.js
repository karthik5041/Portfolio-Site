// Smooth scroll (native via CSS in modern browsers), add small enhancement
document.addEventListener('DOMContentLoaded', () => {
  console.log('Portfolio loaded');
});
